% Dense Flow-based Affine/Similarity Image Transform Face Registration
% COPYRIGHT: Songfan Yang, VISLab(www.vislab.ucr.edu), University of 
%       California, Riverside
%
% REFERENCE: [Yang_FG13] Yang et al., Improving Action Units Recognition 
%       Using Dense Flow-based Face Registration in Video, FG, 2013

% INTRODUCATION
% This software library in accordance with the [Yang_FG13], which can be
% found in the reference folder. This face registration techinique is
% suitable for online streaming data, i.e. video-based face processing.
% This technique achieves robust performance under the condition of
% in-plane rotation, changing resolution, minor out-of-plane rotation. The
% user should notice that only the core part of the software is provided in
% unoptimized Matlab code for research purposes. 

% This library provides 2 registration modes
%   1. SIFT-flow similarity transform on the first frame + Optical-flow
%   similarity on the consecutive frames.
%   2. No SIFT-flow similarity transform on the first frame

% EXAMPLE OF USAGE:
% ================ skip to step 2 if you use x64 system =============
%   1. build library by running build_lib.m. The lib has been precompile
%       for x64 systems
% ===================================================================
%   2. select process mode: 
%       (a) mode 1: INIT_PROC = true;
%       (b) mode 2: INIT_PROC = false;
%   3. create a sequence subfolder in the data folder, and place your data 
%       in the subfolder.
%   4. run this script and the registration results are saved in the
%       corresponding subfolder in result folder.

% SUGGESTION OF USAGE:
%   1. If you only need non-rigid face muscle motion and temporal 
%      smoothness, and do not want to align faces with the reference, 
%      select mode 2.
%   2. Since we didn't incorporate TILT and alignment verification steps
%      described in the [Yang_FG13] in this library, therefore, the first 
%      frame should include a near frontal face image for better results.

% AUTHOR:	Songfan Yang, Univerity of California, Riverside.
% CONTACT:  songfan.yang@email.ucr.edu
% DATE:     December 02,2012

clc;clear all;close all;
addpath('./SOFSIT_lib');
addpath('./SIFTflow');
addpath('./MOpenCV');

%% Select process mode:
INIT_PROC = true;

%% Set up input path for your data
% the registration result is saved in out_loc folder
% feel free adapt to your data path setting
folder_name = 'seq2';
in_loc  = './data/';
out_loc = './result/';

if exist([out_loc,folder_name],'dir')
    rmdir([out_loc,folder_name],'s');
end
mkdir([out_loc,folder_name]);
frames = dir([in_loc,folder_name,'/*.jpg']);
f_num = length(frames);
%% Registration paramter
setupPara
% read avatar reference face (Please see [Yang_FERA11] and [Yang_SMC12] for detail)
load('avt_ref_1_ck.mat');

%% Process the first frame
disp('Dense Flow-based Face Registration...')
im = imread([in_loc,folder_name,'/',frames(1,1).name]);
im_cur_unreg = sf_preproc(im,sofsit.HEAD_SIZE);
if INIT_PROC
    [A_sift,warpI2] = sf_siftFlowSimilarity(avt_ref,im_cur_unreg,true);
    imwrite(sf_norm(warpI2),[out_loc,folder_name,'/',frames(1,1).name],'jpg');
else
    imwrite(im_cur_unreg,[out_loc,folder_name,'/',frames(1,1).name],'jpg');
    A_sift = eye(3);
end
% cumulate transformation matrix
A = A_sift; 

%% compute optical flow for the rest of the sequence
for f_ind = 2:f_num
    im_next = imread([in_loc,folder_name,'/',frames(f_ind,1).name]);
    im_next_unreg = sf_preproc(im_next,sofsit.HEAD_SIZE);

    % optical flow align
    A_opt = sf_opticalFlowSimilarity(im_cur_unreg, im_next_unreg, false);

    % warp current frame to the first frame
    A = A*A_opt;
    Iwarp2 = A*sofsit.I2;
    x1 = reshape(Iwarp2(1,:),[sofsit.HEAD_SIZE,sofsit.HEAD_SIZE]);
    y1 = reshape(Iwarp2(2,:),[sofsit.HEAD_SIZE,sofsit.HEAD_SIZE]);
    vx = (x1-sofsit.x0_h);     
    vy = (y1-sofsit.y0_h); 
    warpI2=warpImage(im_next_unreg,vx,vy);
    imwrite(sf_norm(warpI2),[out_loc,folder_name,'/',frames(f_ind,1).name],'jpg');
    im_cur_unreg = im_next_unreg;

    if rem(f_ind,10)==0
        disp([num2str(f_ind),'/',num2str(f_num)]);
    end
end


