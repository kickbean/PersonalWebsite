% ++++++ Please skip this file if you have a x64 system ++++++++++
% build library
% note: all the libs have been precompiled for x64 machines

% AUTHOR:	Songfan Yang, Univerity of California, Riverside.
% CONTACT:  songfan.yang@email.ucr.edu

base_loc = pwd;
% optical flow
% you need to adjust make_cvlib.m according to your OpenCV path
dir('./MOpenCV')
make_cvlib
dir(base_loc)

% Sift flow
dir('./SIFTflow/mexDenseSIFT')
mex mexDenseSIFT.cpp Matrix.cpp Vector.cpp
dir('../mexDiscreteFlow')
mex mexDiscreteFlow.cpp BPFlow.cpp Stochastic.cpp
dir(base_loc)
