function A = sf_calcSimilarity(cor_in,cor_out)
% AUTHOR:	Songfan Yang, Univerity of California, Riverside.
% CONTACT:  songfan.yang@email.ucr.edu

AA = cor_in;
bx = cor_out(:,1);
by = cor_out(:,2);

a123 = robustfit(AA,bx);
a456 = robustfit(AA,by);

A = eye(3,3);
A(1,3) = a123(1);
A(1,1) = a123(2);
A(1,2) = a123(3);
A(2,3) = a456(1);
A(2,1) = a456(2);
A(2,2) = a456(3);

s = sqrt(A(2,2)*A(1,1)+A(1,2)*A(2,1));
A = A/s;
[U,~,V] = svd(A(1:2,1:2));
A(1:2,1:2) = U*V';
A = A*s;