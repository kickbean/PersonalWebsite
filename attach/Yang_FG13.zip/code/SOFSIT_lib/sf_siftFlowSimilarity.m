% SIFT flow based similarity transformation for registration
function [A,warpI2] = sf_siftFlowSimilarity(im1,im2,warp)
% AUTHOR:	Songfan Yang, Univerity of California, Riverside.
% CONTACT:  songfan.yang@email.ucr.edu

%%%%%%%%%%%%%%%%%%%
% sift flow parameter
cellsize=1;
gridspacing=1;
SIFTflowpara.alpha=2*255;
SIFTflowpara.d=40*255;
SIFTflowpara.gamma=0.005*255;
SIFTflowpara.nlevels=4;
SIFTflowpara.wsize=1;
SIFTflowpara.topwsize=10;
SIFTflowpara.nTopIterations = 60;
SIFTflowpara.nIterations= 30;
%%%%%%%%%%%%%%%%%%%
sift1 = mexDenseSIFT(im1,cellsize,gridspacing);
sift2 = mexDenseSIFT(im2,cellsize,gridspacing);
[vx,vy,~]=SIFTflowc2f(sift1,sift2,SIFTflowpara);
% compute similarity transform based on SIFT flow vector
global sofsit
x1 = sofsit.x0_f + ...
    vx(sofsit.MARGIN_TOP+1:end,sofsit.MARGIN_L+1:end-sofsit.MARGIN_R);
y1 = sofsit.y0_f + ...
    vy(sofsit.MARGIN_TOP+1:end,sofsit.MARGIN_L+1:end-sofsit.MARGIN_R);

cor_out = [x1(:), y1(:)];
% compute affine and warp the image
A = sf_calcSimilarity(sofsit.cor_in_f,cor_out);
warpI2 = [];
if(warp)
    Iwarp2 = A*sofsit.I2;
    x1 = reshape(Iwarp2(1,:),[sofsit.HEAD_SIZE,sofsit.HEAD_SIZE]);
    y1 = reshape(Iwarp2(2,:),[sofsit.HEAD_SIZE,sofsit.HEAD_SIZE]);
    vx = (x1-sofsit.x0_h);
    vy = (y1-sofsit.y0_h);
    warpI2=warpImage(im2,vx,vy);
end