% dense optical flow based affine for registration
function [A,warpI2] = sf_opticalFlowSimilarity(im1, im2, warp)
% AUTHOR:	Songfan Yang, Univerity of California, Riverside.
% CONTACT:  songfan.yang@email.ucr.edu

global sofsit
cor_out = cvlib_mex('opticalFlowPyrLK', im1, im2, sofsit.cor_in_h, 7,4,20,0.0001);

diff = cor_out-sofsit.cor_in_h;      
perc = 1;
sz = size(diff,1);
% keep 99% of the points
ptsx = abs(diff(:,1));
ptsx_sort= sort(ptsx,'descend');
tx = ptsx_sort(sz*perc/100);
diffx = diff(:,1);
diffx(abs(diffx)>tx)=0;
diff(:,1) = diffx;

ptsy = abs(diff(:,2));
ptsy_sort= sort(ptsy,'descend');
ty = ptsy_sort(sz*perc/100);
diffy = diff(:,2);
diffy(abs(diffy)>ty)=0;
diff(:,2) = diffy;

cor_out1 = sofsit.cor_in_h + diff;

%% compute affine transform matrix
A = sf_calcSimilarity(sofsit.cor_in_h,cor_out1);
if(warp)
    Iwarp2 = A*sofsit.I2;
    x1 = reshape(Iwarp2(1,:),[sofsit.HEAD_SIZE,sofsit.HEAD_SIZE]);
    y1 = reshape(Iwarp2(2,:),[sofsit.HEAD_SIZE,sofsit.HEAD_SIZE]);
    vx = (x1-sofsit.x0_h);
    vy = (y1-sofsit.y0_h);
    warpI2=warpImage(im2,vx,vy);
end