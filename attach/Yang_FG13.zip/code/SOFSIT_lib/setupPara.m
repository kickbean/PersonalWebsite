% SOFSIT parameter set up

% AUTHOR:	Songfan Yang, Univerity of California, Riverside.
% CONTACT:  songfan.yang@email.ucr.edu
global sofsit;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sofsit.HEAD_SIZE = 200;     

sofsit.MARGIN_L = 30; 
sofsit.MARGIN_R = 30;       sofsit.MARGIN_TOP = 40;

% optical flow parameter for head
[sofsit.x0_h sofsit.y0_h] = meshgrid(1:sofsit.HEAD_SIZE,1:sofsit.HEAD_SIZE);
x_h = sofsit.x0_h(:); y_h = sofsit.y0_h(:);
sofsit.cor_in_h = [x_h,y_h];
sofsit.I2 = [sofsit.cor_in_h, ones(size(sofsit.cor_in_h,1),1)]';

% for face area
sofsit.x0_f = sofsit.x0_h(sofsit.MARGIN_TOP+1:end,sofsit.MARGIN_L+1:end-sofsit.MARGIN_R);
sofsit.y0_f = sofsit.y0_h(sofsit.MARGIN_TOP+1:end,sofsit.MARGIN_L+1:end-sofsit.MARGIN_R);
sofsit.cor_in_f = [sofsit.x0_f(:),sofsit.y0_f(:)];

