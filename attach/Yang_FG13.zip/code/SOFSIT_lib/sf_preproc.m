function im_out = sf_preproc(im,HEAD_SIZE)
% AUTHOR:	Songfan Yang, Univerity of California, Riverside.
% CONTACT:  songfan.yang@email.ucr.edu

s = size(im);
if length(s)==3
    im=rgb2gray(im);
end
im=imresize(im,[HEAD_SIZE HEAD_SIZE]);
im_out=histeq(im);