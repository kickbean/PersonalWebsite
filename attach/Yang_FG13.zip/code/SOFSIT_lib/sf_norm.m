function im_n = sf_norm(im)
% AUTHOR:	Songfan Yang, Univerity of California, Riverside.
% CONTACT:  songfan.yang@email.ucr.edu

p_max = max(max(im));
p_min = min(min(im));
im_n = (im-p_min)/(p_max-p_min);