function make_cvlib()
%  make_cvlib -- Make the cvlib_mex in windows. It probably will
%  work as well in Linux/Mac with only minor changes
%
%  Author:	Joaquim Luis
%  Date:	07-Sept-2006


% Adjust for your own path
INCLUDE_CV = 'C:\OpenCV2.1\include\';
INCLUDE_CXCORE = 'C:\OpenCV2.1\include\opencv\';
LIB_CV = 'C:\OpenCV2.1\lib64\cv210.lib';
LIB_CXCORE = 'C:\OpenCV2.1\lib64\cxcore210.lib';

% -------------------------- Stop editing ---------------------------
include_cv = ['-I' INCLUDE_CV ' -I' INCLUDE_CXCORE];
library_cv = [LIB_CV ' ' LIB_CXCORE];

if (ispc)
    opt_cv = '-O -DWIN32 -DDLL_CV210 -DDLL_CXCORE210';
else
    opt_cv = '-O';
end
        
cmd = ['mex cvlib_mex.c' ' ' include_cv ' ' library_cv ' ' opt_cv ' -v'];        
eval(cmd)
    
